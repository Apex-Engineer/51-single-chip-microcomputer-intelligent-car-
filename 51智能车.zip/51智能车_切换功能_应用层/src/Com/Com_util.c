#include "Com_util.h"

//void Delay_ms(u16 nms){
//	while (nms--)
//    {
//        unsigned char data i, j;

//        _nop_();
//        i = 2;
//        j = 199;
//	    do
//	{
//		while (--j);
//	} while (--i);
//    }

//}
void Delay_10us(void)
{
    unsigned char data i;

    i = 2;
    while (--i);
}


