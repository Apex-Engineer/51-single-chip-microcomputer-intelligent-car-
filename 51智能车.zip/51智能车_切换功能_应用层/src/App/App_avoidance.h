#ifndef __APP_AVOIDANCE_H__
#define __APP_AVOIDANCE_H__

#include "Com_util.h"
#include "Com_GPIO.h"
#include "Int_motor.h"
#include "Int_rader.h"
#include "Int_buzzer.h"
#include "Int_OLED.h"


/**
 * @brief ��Ҫѭ�����õı��Ͽ����߼�
 * 
 */
void App_avoidance_control(void);


#endif /* __APP_AVOIDANCE_H__ */