#include "App_avoidance.h"

static u8 str[17];
void App_avoidance_control(void)
{
    //ʹ�ó�������ȡǰ���ϰ���ľ���
    u16 dis =Int_rader_getdistance();

   #ifdef DEBUG
   sprintf(str,"dis:%u             ",dis);
    Int_OLED_displaystring(str,0,0);

   #endif // DEBUG
    //�ж��Ƿ�С��300
    if (dis<200)
    {
        //��������
        Int_buzzer_buzz(300);

        //��ת
        Int_motor_setleft(40);
        Int_motor_setright(-40);

#ifdef DEBUG
Int_OLED_displaystring("turn right    ",0,1);
    
#endif // DEBUG
        
        }
    else{
        //ֱ��
        Int_motor_setleft(40);
        Int_motor_setright(40);

        #ifdef DEBUG
        Int_OLED_displaystring("go forward    ",0,1);
 
        #endif // DEBUG
           }
    
}