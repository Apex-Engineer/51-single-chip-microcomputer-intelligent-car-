#ifndef __APP_PATROL_H__
#define __APP_PATROL_H__

#include "Com_util.h"
#include "Com_GPIO.h"
#include "Int_motor.h"
#include "Int_OLED.h"
#include "Int_sensor.h"

/**
 * @brief ѭ������ʵ��Ѳ�߹���
 * 
 */
void App_patrol_control(void);

#endif /* __APP_PATROL_H__ */